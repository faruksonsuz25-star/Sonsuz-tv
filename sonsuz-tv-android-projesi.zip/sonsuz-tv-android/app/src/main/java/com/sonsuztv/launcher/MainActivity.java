package com.sonsuztv.launcher;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {

    private WebView webView;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Keep screen awake while mirrored over MHL to TV
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideSystemUI();

        webView = new WebView(this);
        webView.setBackgroundColor(0xFF0B0F17);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        settings.setBlockNetworkLoads(true); // 0 KB background data usage

        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new TvBridge(), "AndroidTV");
        webView.loadUrl("file:///android_asset/index.html");

        setContentView(webView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemUI();
    }

    private void hideSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
        );
    }

    // Forward TV Remote (HDMI-CEC/RCP) & Bluetooth Remote D-Pad keys to JS UI
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            String jsCmd = null;
            switch (event.getKeyCode()) {
                case KeyEvent.KEYCODE_DPAD_UP:
                    jsCmd = "window.sonsuzRemote && window.sonsuzRemote('up')";
                    break;
                case KeyEvent.KEYCODE_DPAD_DOWN:
                    jsCmd = "window.sonsuzRemote && window.sonsuzRemote('down')";
                    break;
                case KeyEvent.KEYCODE_DPAD_LEFT:
                    jsCmd = "window.sonsuzRemote && window.sonsuzRemote('left')";
                    break;
                case KeyEvent.KEYCODE_DPAD_RIGHT:
                    jsCmd = "window.sonsuzRemote && window.sonsuzRemote('right')";
                    break;
                case KeyEvent.KEYCODE_DPAD_CENTER:
                case KeyEvent.KEYCODE_ENTER:
                    jsCmd = "window.sonsuzRemote && window.sonsuzRemote('ok')";
                    break;
                case KeyEvent.KEYCODE_BACK:
                case KeyEvent.KEYCODE_ESCAPE:
                    jsCmd = "window.sonsuzRemote && window.sonsuzRemote('back')";
                    break;
                default:
                    break;
            }
            if (jsCmd != null && webView != null) {
                final String cmd = jsCmd;
                runOnUiThread(() -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                        webView.evaluateJavascript(cmd, null);
                    } else {
                        webView.loadUrl("javascript:" + cmd);
                    }
                });
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    private class TvBridge {
        @JavascriptInterface
        public boolean launchApp(String target) {
            if (target == null || target.trim().isEmpty()) return false;
            final String cleanTarget = target.trim();
            try {
                if (cleanTarget.startsWith("http://") || cleanTarget.startsWith("https://")) {
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(cleanTarget));
                    browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(browserIntent);
                    return true;
                }
                PackageManager pm = getPackageManager();
                Intent launchIntent = pm.getLaunchIntentForPackage(cleanTarget);
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(launchIntent);
                    return true;
                }
                runOnUiThread(() -> Toast.makeText(
                        MainActivity.this,
                        "Uygulama telefonda bulunamadi: " + cleanTarget,
                        Toast.LENGTH_SHORT
                ).show());
                return false;
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(
                        MainActivity.this,
                        "Uygulama acilamadi.",
                        Toast.LENGTH_SHORT
                ).show());
                return false;
            }
        }

        @JavascriptInterface
        public String getInstalledAppsJson() {
            try {
                PackageManager pm = getPackageManager();
                Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
                mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> apps = pm.queryIntentActivities(mainIntent, 0);
                Collections.sort(apps, new Comparator<ResolveInfo>() {
                    @Override
                    public int compare(ResolveInfo a, ResolveInfo b) {
                        return String.valueOf(a.loadLabel(pm))
                                .compareToIgnoreCase(String.valueOf(b.loadLabel(pm)));
                    }
                });
                JSONArray arr = new JSONArray();
                for (ResolveInfo info : apps) {
                    String pkg = info.activityInfo.packageName;
                    if (pkg.equals(getPackageName())) continue;
                    JSONObject obj = new JSONObject();
                    obj.put("name", String.valueOf(info.loadLabel(pm)));
                    obj.put("packageName", pkg);
                    arr.put(obj);
                }
                return arr.toString();
            } catch (Exception e) {
                return "[]";
            }
        }
    }
}
